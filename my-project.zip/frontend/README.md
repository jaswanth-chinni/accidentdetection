# AIOT Accident Detection — React frontend

A small, practical React dashboard intended to sit beside `backend/` in the project root. It uses the existing Flask API and does not run detection in the browser.

## Folder placement

Extract this folder so the project looks like:

```text
AIOT-Accident-Detection/
├── frontend/
│   ├── package.json
│   ├── .env                 # create from .env.example
│   └── src/
├── backend/
├── data/
├── assets/
├── models/
└── .env                     # existing backend configuration
```

## Requirements

Install Node.js LTS (npm is included). You do not need to install Node packages globally.

## Install and run (Windows PowerShell)

1. Open a **second** terminal in VS Code (leave the Flask backend running in the first terminal).
2. Move into the frontend folder:

   ```powershell
   cd "C:\path\to\AIOT-Accident-Detection\frontend"
   ```

3. Create the frontend environment file:

   ```powershell
   Copy-Item .env.example .env
   ```

   For local development on the same PC, keep `VITE_BACKEND_URL=http://localhost:5000`.

4. Install the packages declared by this frontend only:

   ```powershell
   npm install
   ```

5. Start React:

   ```powershell
   npm run dev
   ```

6. Open the URL Vite prints, normally `http://localhost:5173`.

The React dependencies install under `frontend/node_modules`. This does not change or reinstall Python packages in `backend/venv`.

## Start the backend

In a separate terminal:

```powershell
cd "C:\path\to\AIOT-Accident-Detection\backend"
.\venv\Scripts\Activate.ps1
python run.py
```

Make sure the existing root `.env` has `FRONTEND_ORIGINS=http://localhost:3000,http://localhost:5173`. The backend `run.py` loads `.env` from the project root.

## What the dashboard uses

- `GET /api/status` — backend and latest-event summary
- `GET /api/accidents?limit=50` — saved history
- `GET /api/events` — Server-Sent Events; listens for `connected` and `accident.detected`
- `GET /api/videos/{filename}` — clip playback
- Camera coordinates from `camera_location` — Google Maps directions after a user clicks the directions button

New events are handled as they arrive; history is deduplicated by `event_id`. If the dashboard was disconnected, it refreshes persisted history when the SSE connection reconnects. If `video_url` is null, it displays an explanation instead of a broken player.

## Using another device

`localhost` means the device running the browser, not the Raspberry Pi. To view the dashboard from another device, set `VITE_BACKEND_URL` in `frontend/.env` to the backend machine's reachable address, e.g. `http://192.168.1.5:5000`, and add the frontend's actual origin to the backend root `.env` `FRONTEND_ORIGINS` setting. Restart both Vite and Flask after changing environment values. Do not expose the Flask development server directly to the public internet.

## Production build check

```powershell
npm run build
```

This writes static files to `frontend/dist/`. `npm run dev` is the simplest development workflow.

## Sample-video major-event test — test configuration only

The frontend never invents or upgrades an accident severity; it displays what Flask sends. To test the major-accident path with your sample video, temporarily change these settings in the **project-root `.env`** (not `frontend/.env`):

```dotenv
VIDEO_SOURCE=sample
MAJOR_SPEED_THRESHOLD=0
MAJOR_ACCELERATION_THRESHOLD=0
ACCIDENT_VIDEO_DIR=./data/accident_clips
CAMERA_LATITUDE=16.5062
CAMERA_LONGITUDE=80.6480
```

With the current `AccidentService.calculate_severity()` formula, zero thresholds make any collision passed to the service classify as `MAJOR`. This is only to exercise the demo pipeline, not a meaningful severity setting. Restore realistic thresholds before any real-camera evaluation/deployment. Restart Flask after changing `.env`.

### Important backend checks for video playback

1. `vehicle_detector.py` must append each processed frame to `pre_event_frames` near the end of the frame loop, before the `if show_window:` block:

   ```python
   pre_event_frames.append(frame.copy())
   ```

   Keep this append reachable even when `result.boxes` is `None`; do not `continue` past it.

2. When a major event is detected, the backend terminal should print `SAVED ACCIDENT CLIP: ...` and the file should appear under the project-root `data/accident_clips/` folder.

3. The video route must resolve `ACCIDENT_VIDEO_DIR` relative to the project root as well as accept absolute paths. Because Flask is normally launched from `backend/`, a plain relative `./data/accident_clips` in `routes.py` otherwise may resolve to `backend/data/accident_clips`, while the detector writes to the project root.

4. Open a clip URL directly in the browser to verify the API route works, e.g. `http://localhost:5000/api/videos/<actual-filename>.mp4`. Use a real filename from the terminal; do not type the placeholder literally.

A major alert with no `video_url` means the frontend received no clip link from the backend. A clip that saves but returns HTTP 404 indicates a backend video-route path mismatch, not a React rendering issue.
