import { useCallback, useEffect, useMemo, useRef, useState } from 'react';

const BACKEND_URL = (import.meta.env.VITE_BACKEND_URL || 'http://localhost:5000').replace(/\/$/, '');
const API = `${BACKEND_URL}/api`;

function absoluteUrl(path) {
  if (!path) return null;
  try { return new URL(path, `${BACKEND_URL}/`).toString(); }
  catch { return null; }
}

function formatDate(value) {
  if (!value) return 'Time unavailable';
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return String(value);
  return date.toLocaleString();
}

function number(value, digits = 2) {
  if (value === null || value === undefined || value === '') return '—';
  const n = Number(value);
  return Number.isFinite(n) ? n.toFixed(digits) : '—';
}

function Severity({ event }) {
  const major = event?.major_accident === true || String(event?.severity || '').toUpperCase() === 'MAJOR';
  return <span className={`severity ${major ? 'severity-major' : 'severity-minor'}`}>{major ? 'MAJOR' : (event?.severity || 'UNKNOWN')}</span>;
}

function EventDetails({ event }) {
  if (!event) return <p className="muted">No accident event has been recorded yet.</p>;
  const location = event.camera_location;
  const video = absoluteUrl(event.video_url);
  return (
    <>
      <div className="event-heading">
        <div>
          <div className="eyebrow">LATEST EVENT</div>
          <h2>{event.event_id || 'Accident event'}</h2>
          <p className="muted">{formatDate(event.timestamp)}</p>
        </div>
        <Severity event={event} />
      </div>
      <div className="detail-grid">
        <div className="detail"><span>Camera</span><strong>{event.camera_id || 'camera-01'}</strong></div>
        <div className="detail"><span>Vehicle IDs</span><strong>{event.vehicle_1 ?? '—'} / {event.vehicle_2 ?? '—'}</strong></div>
        <div className="detail"><span>Estimated distance</span><strong>{number(event.distance)}</strong></div>
        <div className="detail"><span>Severity score</span><strong>{event.severity_score ?? '—'}</strong></div>
        <div className="detail"><span>Vehicle 1 speed estimate</span><strong>{number(event.speed_1)}</strong></div>
        <div className="detail"><span>Vehicle 2 speed estimate</span><strong>{number(event.speed_2)}</strong></div>
        <div className="detail"><span>Vehicle 1 acceleration estimate</span><strong>{number(event.acceleration_1)}</strong></div>
        <div className="detail"><span>Vehicle 2 acceleration estimate</span><strong>{number(event.acceleration_2)}</strong></div>
      </div>
      <p className="note">Speed, distance and acceleration are detector estimates, not calibrated real-world measurements.</p>
      {event.storage_warning && <div className="inline-warning">{event.storage_warning}</div>}
      <section className="evidence-section">
        <div className="section-heading"><h3>Video evidence</h3>{video && <a href={video} target="_blank" rel="noreferrer">Open clip separately</a>}</div>
        {video ? (
          <video className="evidence-video" controls preload="metadata" src={video}>
            Your browser does not support HTML video.
          </video>
        ) : (
          <div className="empty-evidence">
            <strong>No video URL supplied by backend</strong>
            <p>{event.major_accident || event.severity === 'MAJOR' ? 'This is a major event, but the backend did not attach a clip. Check the backend clip-save logs and video endpoint.' : 'The current backend saves clips for major accidents only. Minor events do not include video.'}</p>
          </div>
        )}
      </section>
      <section className="location-section">
        <div className="section-heading"><h3>Camera location</h3></div>
        {location && Number.isFinite(Number(location.latitude)) && Number.isFinite(Number(location.longitude)) ? (
          <>
            <p className="coordinates">{Number(location.latitude).toFixed(6)}, {Number(location.longitude).toFixed(6)}</p>
            <button className="button button-secondary" onClick={() => openDirections(location)}>Get directions in Google Maps</button>
          </>
        ) : <p className="muted">Camera coordinates were not included in this event. Set CAMERA_LATITUDE and CAMERA_LONGITUDE in the backend .env file.</p>}
      </section>
    </>
  );
}

function openDirections(location) {
  const destination = `${location.latitude},${location.longitude}`;
  const open = (origin) => {
    const params = new URLSearchParams({ api: '1', destination, travelmode: 'driving' });
    if (origin) params.set('origin', `${origin.latitude},${origin.longitude}`);
    window.open(`https://www.google.com/maps/dir/?${params.toString()}`, '_blank', 'noopener,noreferrer');
  };
  if (!navigator.geolocation) {
    open(null);
    return;
  }
  navigator.geolocation.getCurrentPosition(
    (position) => open({ latitude: position.coords.latitude, longitude: position.coords.longitude }),
    () => open(null),
    { enableHighAccuracy: false, timeout: 8000, maximumAge: 60000 }
  );
}

export default function App() {
  const [service, setService] = useState({ status: 'checking', accident_detected: false, latest_collision: null, total_accidents: 0 });
  const [history, setHistory] = useState([]);
  const [connection, setConnection] = useState('connecting');
  const [loadingHistory, setLoadingHistory] = useState(true);
  const [apiError, setApiError] = useState('');
  const [notice, setNotice] = useState(null);
  const [filter, setFilter] = useState('ALL');
  const eventSourceRef = useRef(null);
  const seenIdsRef = useRef(new Set());

  const mergeHistory = useCallback((incoming) => {
    if (!Array.isArray(incoming)) return;
    setHistory((current) => {
      const byId = new Map();
      [...current, ...incoming].forEach((item) => {
        if (item && item.event_id) byId.set(item.event_id, item);
      });
      const merged = [...byId.values()].sort((a, b) => new Date(b.timestamp || 0).getTime() - new Date(a.timestamp || 0).getTime());
      seenIdsRef.current = new Set(merged.map((item) => item.event_id));
      return merged;
    });
  }, []);

  const refreshStatus = useCallback(async () => {
    const response = await fetch(`${API}/status`);
    if (!response.ok) throw new Error(`Status endpoint returned HTTP ${response.status}`);
    const data = await response.json();
    setService(data);
    if (data.latest_collision) {
      setHistory((current) => {
        const byId = new Map(current.map((item) => [item.event_id, item]));
        if (data.latest_collision.event_id) byId.set(data.latest_collision.event_id, data.latest_collision);
        return [...byId.values()].sort((a, b) => new Date(b.timestamp || 0).getTime() - new Date(a.timestamp || 0).getTime());
      });
    }
  }, []);

  const refreshHistory = useCallback(async () => {
    setLoadingHistory(true);
    try {
      const response = await fetch(`${API}/accidents?limit=50`);
      if (!response.ok) throw new Error(`History endpoint returned HTTP ${response.status}`);
      const data = await response.json();
      mergeHistory(data.items || []);
      setApiError('');
    } catch (error) {
      setApiError(error.message || 'Unable to load accident history.');
    } finally {
      setLoadingHistory(false);
    }
  }, [mergeHistory]);

  useEffect(() => {
    let alive = true;
    Promise.allSettled([refreshStatus(), refreshHistory()]).then((results) => {
      if (!alive) return;
      const failed = results.find((r) => r.status === 'rejected');
      if (failed) setApiError(failed.reason?.message || 'Unable to reach backend.');
    });

    const source = new EventSource(`${API}/events`);
    eventSourceRef.current = source;
    source.addEventListener('connected', () => {
      setConnection('connected');
      // SSE does not replay events missed while disconnected, so refresh persisted history.
      refreshHistory();
      refreshStatus().catch(() => {});
    });
    source.addEventListener('open', () => setConnection('connected'));
    source.addEventListener('accident.detected', (message) => {
      try {
        const event = JSON.parse(message.data);
        if (!event || typeof event !== 'object') return;
        const isNew = !event.event_id || !seenIdsRef.current.has(event.event_id);
        mergeHistory([event]);
        setService((current) => ({
          ...current,
          status: current.status === 'checking' ? 'running' : current.status,
          accident_detected: true,
          latest_collision: event,
          total_accidents: current.total_accidents || 0
        }));
        if (isNew) setNotice(event);
        setApiError(event.storage_warning || '');
      } catch {
        setApiError('Received an accident event that could not be parsed.');
      }
    });
    source.onerror = () => setConnection('reconnecting');

    return () => {
      alive = false;
      source.close();
      eventSourceRef.current = null;
    };
  }, [refreshHistory, refreshStatus, mergeHistory]);

  const latest = service.latest_collision || history[0] || null;
  const filteredHistory = useMemo(() => filter === 'ALL' ? history : history.filter((event) => String(event.severity || '').toUpperCase() === filter), [history, filter]);
  const majorCount = history.filter((event) => event.major_accident === true || String(event.severity).toUpperCase() === 'MAJOR').length;

  return (
    <main className="page-shell">
      <header className="topbar">
        <div className="brand-mark" aria-hidden="true">AD</div>
        <div className="brand-copy"><h1>Accident Detection</h1><p>Camera monitoring dashboard</p></div>
        <div className={`connection-state connection-${connection}`}><span className="connection-dot" />{connection === 'connected' ? 'Live connection' : connection === 'reconnecting' ? 'Reconnecting' : 'Connecting'}</div>
      </header>

      {notice && (
        <section className={`alert-banner ${(notice.major_accident || String(notice.severity).toUpperCase() === 'MAJOR') ? 'alert-major' : 'alert-minor'}`} role="alert">
          <div><strong>{(notice.major_accident || String(notice.severity).toUpperCase() === 'MAJOR') ? 'Major accident detected' : 'Accident event detected'}</strong><p>{notice.event_id || 'New event'} · {formatDate(notice.timestamp)}</p></div>
          <button className="dismiss-button" onClick={() => setNotice(null)} aria-label="Dismiss alert">Dismiss</button>
        </section>
      )}

      {apiError && <div className="error-banner"><strong>Backend notice:</strong> {apiError} <button onClick={() => setApiError('')} aria-label="Dismiss backend notice">×</button></div>}

      <section className="summary-grid" aria-label="System summary">
        <div className="summary-card"><span>Backend status</span><strong className={service.status === 'running' ? 'text-good' : service.status === 'degraded' ? 'text-bad' : ''}>{service.status || 'checking'}</strong><small>{service.database_error ? 'Database connection needs attention' : 'Flask API'}</small></div>
        <div className="summary-card"><span>Saved accident records</span><strong>{service.total_accidents ?? history.length}</strong><small>Reported by backend</small></div>
        <div className="summary-card"><span>Major events in loaded history</span><strong>{majorCount}</strong><small>Based on returned event records</small></div>
        <div className="summary-card"><span>Event stream</span><strong className={connection === 'connected' ? 'text-good' : 'text-bad'}>{connection}</strong><small>Server-Sent Events</small></div>
      </section>

      <div className="main-grid">
        <section className="panel latest-panel">
          <div className="panel-header"><div><div className="eyebrow">EVENT DETAILS</div><h2>Latest accident</h2></div><button className="button button-secondary button-small" onClick={() => { refreshStatus().catch((e) => setApiError(e.message)); refreshHistory(); }}>Refresh</button></div>
          <EventDetails event={latest} />
        </section>

        <aside className="panel history-panel">
          <div className="panel-header history-heading"><div><div className="eyebrow">RECENT ACTIVITY</div><h2>Accident history</h2></div><span className="count-pill">{history.length}</span></div>
          <div className="history-controls">
            <label htmlFor="severity-filter">Show</label>
            <select id="severity-filter" value={filter} onChange={(e) => setFilter(e.target.value)}>
              <option value="ALL">All severities</option><option value="MAJOR">Major only</option><option value="MINOR">Minor only</option>
            </select>
          </div>
          {loadingHistory && history.length === 0 ? <p className="muted history-message">Loading accident history…</p> :
            filteredHistory.length === 0 ? <p className="muted history-message">No matching accident records were returned by the backend.</p> : (
              <div className="history-list">
                {filteredHistory.map((event) => (
                  <button className={`history-item ${latest?.event_id === event.event_id ? 'history-item-active' : ''}`} key={event.event_id || `${event.timestamp}-${event.vehicle_1}`} onClick={() => setService((current) => ({ ...current, latest_collision: event }))}>
                    <div className="history-item-top"><Severity event={event} /><span className="history-time">{formatDate(event.timestamp)}</span></div>
                    <strong>{event.event_id || 'Accident event'}</strong>
                    <span className="history-subtitle">Vehicles {event.vehicle_1 ?? '—'} and {event.vehicle_2 ?? '—'}</span>
                    <span className={`video-state ${event.video_url ? 'video-available' : ''}`}>{event.video_url ? 'Video available' : 'No video URL'}</span>
                  </button>
                ))}
              </div>
            )}
          <p className="history-footnote">History is loaded from the backend. New events should appear here automatically while this dashboard is connected.</p>
        </aside>
      </div>

      <footer className="footer"><span>Backend API: <code>{BACKEND_URL}</code></span><span>Prototype dashboard · Estimates are not calibrated measurements</span></footer>
    </main>
  );
}
