# AIOT Accident Detection — Raspberry Pi + Dashboard API

## Architecture
Pi Camera / USB camera -> Raspberry Pi (YOLO + tracking + collision heuristic) -> Flask API + SSE -> frontend dashboard. MongoDB stores event metadata. Major-event clips are saved locally and served through the API.

## Project layout
- `backend/run.py`: application startup and camera/video source selection.
- `backend/app/detection/vehicle_detector.py`: frame capture, YOLO tracking, event clip creation.
- `backend/app/collision/collision_detector.py`: proximity/closing-motion heuristic.
- `backend/app/services/accident_service.py`: severity heuristic, event record and push notification.
- `backend/app/services/event_bus.py`: connected-dashboard event fan-out.
- `backend/app/api/routes.py`: REST endpoints, SSE stream, video delivery.
- `backend/app/database/mongodb.py`: MongoDB persistence.
- `models/yolov8n.pt`: YOLO model.
- `assets/videos/`: sample videos for local development.
- `FRONTEND_CONTRACT.txt`: API contract for frontend developer.

## Setup (desktop development)
1. Install Python 3.10 or 3.11 in a virtual environment.
2. Install dependencies: `pip install -r requirements.txt`.
3. Start MongoDB locally, or set `MONGODB_URI` to your MongoDB deployment.
4. Copy `.env.example` to `.env` and export the variables in your shell. The backend loads `.env` from the project root. In production, configure environment variables through the OS/service manager.
5. Copy `.env.example` to `.env`. For a sample video, set `VIDEO_SOURCE=sample`. For a USB or Pi camera, set `VIDEO_SOURCE=camera` and configure the camera settings.
6. Start from the `backend` directory: `python run.py`.
7. Check `http://localhost:5000/` and `http://localhost:5000/api/status`.

## Raspberry Pi camera notes
- For the Raspberry Pi CSI camera, install Picamera2 using the Raspberry Pi OS package manager (`sudo apt install python3-picamera2`) and run the application in an environment that can import the system package. Avoid forcing pip to replace Raspberry Pi OS camera packages.
- YOLO/Ultralytics/PyTorch support and performance vary by Pi model, OS, Python version and accelerator. Confirm compatible ARM wheels and benchmark frame rate on the target device before deployment.
- Set `CAMERA_LATITUDE` and `CAMERA_LONGITUDE` to the fixed installation coordinates of the camera. They are not GPS readings of the dashboard user.
- For remote access, use a VPN or authenticated HTTPS reverse proxy. Do not expose the development Flask server directly to the public internet.

## Important limitations
The current collision/severity logic is heuristic and uses image-space motion values, not calibrated real-world speed. Its thresholds are not validated medical/emergency-grade severity criteria. Treat alerts as decision support until evaluated against labeled footage. Event delivery is real-time to connected clients in this process; events are not replayed to clients that were offline. The MongoDB record list can be fetched after reconnecting.

## Environment
See `.env.example`. In production, configure environment variables through the OS/service manager. The `/api/accident/reset` endpoint is disabled unless `ALLOW_ACCIDENT_RESET=true` and should only be enabled for local development.
