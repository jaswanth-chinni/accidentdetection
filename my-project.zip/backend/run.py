import os
import threading
import time
from pathlib import Path
from flask import Flask, jsonify
from dotenv import load_dotenv
from flask_cors import CORS
from app.api.routes import api, set_accident_service
from app.services.accident_service import AccidentService
from app.detection.vehicle_detector import VehicleDetector

ROOT = Path(__file__).resolve().parents[1]
load_dotenv(ROOT / ".env")
app = Flask(__name__)
allowed_origins = [x.strip() for x in os.getenv("FRONTEND_ORIGINS", "http://localhost:3000,http://localhost:5173").split(",") if x.strip()]
CORS(app, resources={r"/api/*": {"origins": allowed_origins}})
accident_service = AccidentService()
set_accident_service(accident_service)
app.register_blueprint(api, url_prefix="/api")

@app.get("/")
def home():
    return jsonify({"service": "AIOT Accident Detection", "status": "running", "api_prefix": "/api"})

def start_detection():
    source = os.getenv("VIDEO_SOURCE", "sample")
    if source.lower() == "sample":
        source = str(ROOT / "assets" / "videos" / os.getenv("SAMPLE_VIDEO", "videoplayback.mp4"))
    detector = VehicleDetector(accident_service=accident_service)
    while True:
        try:
            print(f"Starting detection source: {source}")
            detector.detect_video(source, live=(source.lower() == "camera"))
            if source.lower() != "camera":
                break
            time.sleep(2)
        except Exception as exc:
            print(f"Detection loop error: {exc}")
            time.sleep(3)

if __name__ == "__main__":
    threading.Thread(target=start_detection, daemon=True, name="accident-detection").start()
    app.run(host=os.getenv("HOST", "0.0.0.0"), port=int(os.getenv("PORT", "5000")), debug=False, threaded=True, use_reloader=False)
