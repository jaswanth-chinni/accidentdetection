import os
from pymongo import MongoClient, DESCENDING


class MongoDB:
    def __init__(self):
        self.client = MongoClient(os.getenv("MONGODB_URI", "mongodb://localhost:27017"), serverSelectionTimeoutMS=2500)
        self.db = self.client[os.getenv("MONGODB_DATABASE", "aiot_accident_detection")]
        self.accidents = self.db["accidents"]

    def insert_accident(self, accident_data):
        result = self.accidents.insert_one(accident_data)
        return str(result.inserted_id)

    def get_latest_accident(self):
        doc = self.accidents.find_one({}, {"_id": 0}, sort=[("timestamp", DESCENDING)])
        return doc

    def get_accidents(self, limit=50):
        return list(self.accidents.find({}, {"_id": 0}).sort("timestamp", DESCENDING).limit(max(1, min(int(limit), 200))))

    def get_total_accidents(self):
        return self.accidents.count_documents({})

    def clear_accidents(self):
        self.accidents.delete_many({})
