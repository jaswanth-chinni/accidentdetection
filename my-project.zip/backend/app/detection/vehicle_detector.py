from ultralytics import YOLO
import cv2
from pathlib import Path
from collections import deque
from datetime import datetime, timezone
import os
import shutil
import subprocess

from ..trackers.byte_tracker import ByteTrackerDetector
from ..utils.vehicle_history import VehicleHistory
from ..utils.speed_calculator import SpeedCalculator
from ..utils.direction_calculator import DirectionCalculator
from ..utils.acceleration_calculator import AccelerationCalculator
from ..collision.collision_detector import CollisionDetector



class VehicleDetector:
    def __init__(self,accident_service):
        projectroot = Path(__file__).resolve().parents[3]
        modelpath = projectroot / "models" / "yolov8n.pt"
        self.model = YOLO(str(modelpath))
        self.tracker = ByteTrackerDetector(str(modelpath))

        self.vehicle_history = VehicleHistory()

        self.speed_calculator = SpeedCalculator()
        self.direction_calculator = DirectionCalculator()
        self.acceleration_calculator = AccelerationCalculator()

        self.collision_detector = CollisionDetector()

        self.accident_service = accident_service

        self.vclasses = {2, 3, 5, 7} #yolo ki okkokka number ki okokka vehicle associate ayidhi so konni vehicles care chestham
            #2: Car, 3: Motorcycle, 5: Bus, 7: Truck
        self.accident_detected = False
        self.confirmed_collisions = []#video motham lo persistent ga collisiosn ni store cheyaniki
    def _open_capture(self, source, live=False):
        if not live:
            return cv2.VideoCapture(str(source))
        # Raspberry Pi CSI cameras normally use libcamera/Picamera2.
        try:
            from picamera2 import Picamera2
            class PiCapture:
                def __init__(self):
                    self.camera = Picamera2()
                    self.camera.configure(self.camera.create_video_configuration(main={"size": (1280, 720), "format": "RGB888"}))
                    self.camera.start()
                    self.ok = True
                def isOpened(self): return self.ok
                def read(self):
                    try:
                        frame = self.camera.capture_array()
                        return True, cv2.cvtColor(frame, cv2.COLOR_RGB2BGR)
                    except Exception:
                        return False, None
                def release(self):
                    try: self.camera.stop()
                    except Exception: pass
            return PiCapture()
        except ImportError:
            # USB cameras can work through OpenCV; CSI users should install picamera2.
            return cv2.VideoCapture(int(os.getenv("CAMERA_INDEX", "0")))

    def _save_event_clip(self, frames, fps=20.0):
        """Save a browser-compatible H.264 MP4 and return its API URL.

        OpenCV writes an intermediate MP4V file. FFmpeg converts it to H.264
        (yuv420p + faststart), which is supported by modern browsers.
        ACCIDENT_VIDEO_DIR may be absolute or relative to the project root.
        """
        if not frames:
            print("CLIP NOT SAVED: no frames available in pre-event buffer")
            return None

        ffmpeg = os.getenv("FFMPEG_PATH") or shutil.which("ffmpeg")
        if not ffmpeg:
            print("CLIP NOT SAVED: FFmpeg was not found. Install FFmpeg and ensure it is on PATH, or set FFMPEG_PATH.")
            return None

        project_root = Path(__file__).resolve().parents[3]
        configured_dir = Path(os.getenv("ACCIDENT_VIDEO_DIR", "data/accident_clips"))
        clip_dir = configured_dir if configured_dir.is_absolute() else project_root / configured_dir
        clip_dir.mkdir(parents=True, exist_ok=True)

        stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
        filename = f"{stamp}.mp4"
        clip_path = clip_dir / filename
        raw_path = clip_dir / f"{stamp}.raw.mp4"
        height, width = frames[0].shape[:2]
        safe_fps = float(fps) if fps and 1 <= float(fps) <= 120 else 20.0
        writer = cv2.VideoWriter(
            str(raw_path), cv2.VideoWriter_fourcc(*"mp4v"), safe_fps, (width, height)
        )
        if not writer.isOpened():
            writer.release()
            print(f"CLIP NOT SAVED: OpenCV could not open video writer: {raw_path}")
            return None

        written_frames = 0
        try:
            for frame in frames:
                if frame is None or len(frame.shape) < 2:
                    continue
                if frame.shape[:2] != (height, width):
                    frame = cv2.resize(frame, (width, height))
                writer.write(frame)
                written_frames += 1
        finally:
            writer.release()

        if written_frames == 0 or not raw_path.exists() or raw_path.stat().st_size == 0:
            print(f"CLIP NOT SAVED: no valid video data written to {raw_path}")
            raw_path.unlink(missing_ok=True)
            return None

        try:
            subprocess.run(
                [ffmpeg, "-hide_banner", "-loglevel", "error", "-y", "-i", str(raw_path),
                 "-an", "-c:v", "libx264", "-pix_fmt", "yuv420p", "-movflags", "+faststart", str(clip_path)],
                check=True, capture_output=True, text=True, timeout=120,
            )
            if not clip_path.exists() or clip_path.stat().st_size == 0:
                raise RuntimeError("FFmpeg completed but the output file is empty or missing")
        except (subprocess.SubprocessError, OSError, RuntimeError) as exc:
            print(f"CLIP NOT SAVED: FFmpeg H.264 conversion failed: {exc}")
            clip_path.unlink(missing_ok=True)
            return None
        finally:
            raw_path.unlink(missing_ok=True)

        print(f"SAVED H.264 ACCIDENT CLIP: {clip_path} ({written_frames} frames)")
        return f"/api/videos/{filename}"

    def detect_video(self, videopath, live=False):
        print("VIDEO/CAMERA SOURCE:", videopath)
        cap = self._open_capture(videopath, live=live)
        if not cap.isOpened():
            print("ERROR: Cannot open camera/video. Check VIDEO_SOURCE, camera permissions and Picamera2 installation.")
            return
        fps = cap.get(cv2.CAP_PROP_FPS) if hasattr(cap, "get") else 20.0
        if not fps or fps < 1 or fps > 120:
            fps = 20.0
        pre_seconds = max(0.0, float(os.getenv("CLIP_PRE_EVENT_SECONDS", "3")))
        post_seconds = max(1.0, float(os.getenv("CLIP_POST_EVENT_SECONDS", "5")))
        pre_event_frames = deque(maxlen=max(1, int(fps * pre_seconds)))
        post_event_frame_count = max(1, int(fps * post_seconds))
        # Major events wait for post-event footage before a clip is saved/published.
        pending_major_clips = {}
        show_window = os.getenv("SHOW_DETECTION_WINDOW", "false").lower() == "true"

        while True:
            ret, frame = cap.read()#ret anedhi frame correct ga read ayyindha ledha ani untundhi  cap.read pakka ga okka frame ne return chestundhi
            if not ret:#video last lo frame undadhi so ret false ayidhi
                break

            results = self.tracker.track(frame)#okokka frame ni bytetracker ki pampistham
#results anedhi oka list and each pos lo Results object untundhi aa frame lo unna vehicle ids aa vehicle box cordinates ,center size untay
#enni frames pampisthe anni Result objects untay ikkada okka frame e pampistunnam so okka Result object untundhi
            active_ids=set()#prati frame lo unna ids duplicated removal kosam set 
            current_positions={}
            current_speeds={}
            current_directions={}
            current_accelerations={}

            result=results[0]#okka frame matrame pampincham kabatti results lo oka ele untundhi
            if result.boxes is not None:
                boxes_to_process = result.boxes
            else:
                boxes_to_process = []

            for box in boxes_to_process:#okkokka box okkokka uralytics Boxes oject okkokka vehicle li okokka vehicle
                vclsno = int(box.cls[0])#cls lo only one ele untundi box.cls pytorch array form lo untundi so int loki marustam
#vclsno anedhi yolo nunchi vachina vehicle ki number cars ki 2 bus ki 5 ala 

                if vclsno not in self.vclasses:
                    continue
                if box.id is None:#bytetracker nunchi vachina continuos id 
                    continue
                vtrackno=int(box.id[0])#vehicleki ichina continuous number vtrackno 
                active_ids.add(vtrackno)
                x1,y1,x2,y2=map(int,#yolo nunchi vachina cordiinates float lo untay opencv ki int kavali
                        box.xyxy[0])#xyxy lo coordinates untay

                xcenter=(x1 + x2) // 2 #floor division
                ycenter=(y1 + y2) // 2
                center=(xcenter, ycenter)

                self.vehicle_history.update(vtrackno,center)#vehicle history lo centers ni append chestundi

                history = self.vehicle_history.get_history(vtrackno)
                speed = self.speed_calculator.calculate_speed(history)
                direction = self.direction_calculator.calculate_direction(history)#dir kavalsina hist lekapothe n/a

                if direction is None:
                    direction_display = "N/A"
                else:
                    direction_display = f"{direction:.0f}"

                acceleration = self.acceleration_calculator.calculate_acceleration(history)

                current_positions[vtrackno] = center
                current_speeds[vtrackno] = speed
                current_directions[vtrackno] = direction
                current_accelerations[vtrackno] = acceleration

                # Keep the YOLO vehicle bounding box in the recorded clip, but no text.
                cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 255, 0), 2)
                cv2.circle(frame, center, 4, (0, 0, 255), -1)

            self.vehicle_history.remove_missing(active_ids)#frame lonunchi vellipoyina vehicles remove
            #current data tho collisions find cheyyadam
            potential_collisions=self.collision_detector.detect(current_positions, current_speeds, current_directions, current_accelerations)
            collision_count=len(potential_collisions)

            if collision_count > 0:
                self.accident_detected = True
                self.confirmed_collisions = potential_collisions.copy()#new list is created instead of reference

                if self.accident_service is not None:
                    for collision in potential_collisions:
                        id1, id2, distance, speed1, speed2, direction_diff, acc1, acc2 = collision
                        pair = tuple(sorted((id1, id2)))
                        severity, _, major = self.accident_service.calculate_severity(speed1, speed2, acc1, acc2)
                        if major:
                            if (pair not in self.accident_service.recorded_major_pairs
                                    and pair not in pending_major_clips):
                                # Keep pre-event frames, then continue collecting footage after detection.
                                pending_major_clips[pair] = {
                                    "collision": collision,
                                    "frames": list(pre_event_frames),
                                    # Include this trigger frame plus the configured post-event window.
                                    "remaining": post_event_frame_count + 1,
                                }
                        else:
                            self.accident_service.record_collision(collision, clip_url=None)

                for collision in potential_collisions:
                    id1, id2, distance, speed1, speed2, *_ = collision#spped2 tarvatha values anni dont care
                    closing_speed = abs(speed1 - speed2)
                    print(f">>> COLLISION CONFIRMED: {id1}-{id2} | Distance: {distance:.2f} | Closing: {closing_speed:.2f}")
#collisions ni draw cheyadam paina
            for collision in potential_collisions:

                id1, id2 = collision[0], collision[1]

                #ippudu aa vehicle frame lo unnayo ledho
                if id1 not in current_positions:
                    continue

                if id2 not in current_positions:
                    continue#if true ee collision skip chesi next danikii veltundi

                center1 = current_positions[id1]
                center2 = current_positions[id2]

                cv2.line(frame, center1, center2, (0, 0, 255), 3)#rendu collision objects madya oka line
                cv2.circle(frame, center1, 10, (0, 0, 255), 2)
                cv2.circle(frame, center2, 10, (0, 0, 255), 2)#vehicles daggara red circles

                midpoint = (
                    (center1[0] + center2[0]) // 2,
                    (center1[1] + center2[1]) // 2
                )#potential collision text ni midpoint daggara pettaniki

#accident detect ayithe paina accident detected ani peddaga ravali
            # Collision lines/circles remain visual markers; no text is burned into clips.
            if self.accident_detected:
                #paina potential kinda confirmed collisions
                for collision in self.confirmed_collisions:

                    id1, id2 = collision[0], collision[1]

                    
                    if id1 not in current_positions:
                        continue

                    if id2 not in current_positions:
                        continue

                    center1 = current_positions[id1]
                    center2 = current_positions[id2]

                    
                    cv2.line(frame, center1, center2, (0, 0, 255), 4)
                    cv2.circle(frame, center1, 12, (0, 0, 255), 3)
                    cv2.circle(frame, center2, 12, (0, 0, 255), 3)
            # Keep status and collision counts in the dashboard, not burned into video frames.
            # The clip contains vehicle boxes and collision markers only.
            pre_event_frames.append(frame.copy())
            if show_window:
                cv2.imshow("Vehicle Detection + Tracking", frame)
                if cv2.waitKey(1) & 0xFF == ord("q"):
                    break

        # A sample video may end before the full post-event window is collected.
        # Save the available frames so a detected major event is not silently lost.
        for pair, pending in list(pending_major_clips.items()):
            clip_url = self._save_event_clip(pending["frames"], fps=fps)
            if clip_url and self.accident_service is not None:
                self.accident_service.record_collision(pending["collision"], clip_url=clip_url)
            else:
                print(f"MAJOR accident clip was not published for pair {pair}: clip save failed")
        pending_major_clips.clear()

        cap.release()
        if show_window:
            cv2.destroyAllWindows()

        print()
        print(" VIDEO PROCESSING FINISHED")
#motham last lo anni collisions priting
        if self.accident_detected:
            print("ACCIDENT DETECTED")
            for collision in self.confirmed_collisions:
                id1, id2, distance, *_ = collision
                print(f"Collision Pair: {id1}-{id2} | Distance: {distance:.2f}")
        else:
            print("No accident detected.")
