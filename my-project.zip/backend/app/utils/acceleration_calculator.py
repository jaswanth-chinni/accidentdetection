import math


class AccelerationCalculator:
    def calculate_acceleration(self,position_history):
        if len(position_history)<3:#acc ki 3 speeds kavali
            return 0.0
        #prev 2 pos
        p1=position_history[-3]
        p2=position_history[-2]
        #last 2 pos
        p3=position_history[-2]
        p4=position_history[-1]

        #speed btw f1,2
        dx1=p2[0]-p1[0]
        dy1=p2[1]-p1[1]

        previous_speed=math.sqrt(
            dx1*dx1+dy1*dy1)

        #Speed btw f2,3
        dx2=p4[0]-p3[0]
        dy2=p4[1]-p3[1]

        current_speed=math.sqrt(dx2*dx2+dy2*dy2)

        #acc is change in sppeed
        acceleration=current_speed-previous_speed

        return round(acceleration,2)