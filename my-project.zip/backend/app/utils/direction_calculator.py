import math
class DirectionCalculator:
    def calculate_direction(self, history):
        if len(history) < 2:
            return None
        previous = history[-2]
        current = history[-1]
        dx = current[0] - previous[0]
        dy = current[1] - previous[1]
        angle = math.degrees(math.atan2(dy, dx))
        if angle < 0:
            angle += 360
        return round(angle, 2)