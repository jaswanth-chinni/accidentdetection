import math
class SpeedCalculator:    
    def calculate_speed(self, history):
        if len(history) < 2:
            return 0.0
        previous = history[-2]
        current = history[-1]
        dx = current[0] - previous[0]
        dy = current[1] - previous[1]
        speed = math.sqrt(
            dx * dx +
            dy * dy
        )
        return round(speed, 2)