from collections import defaultdict


class VehicleHistory:
    def __init__(self, maxhist=100):#vehicle ki cont number and center store
        self.maxhist = maxhist
        self.hist = defaultdict(list)

    def update(self, vtrackno, center):#prati individual vehicle ki centers store 
        self.hist[vtrackno].append(center)
        if len(self.hist[vtrackno]) > self.maxhist:#maxhist datithe old trackno pop chesta
            self.hist[vtrackno].pop(0)

    def get_history(self, vtrackno):
        return self.hist.get(vtrackno, [])#vehicle no and anni centers return kosam

    def remove_missing(self, active_ids):
        inactive = []

        for vtrackno in self.hist:
            if vtrackno not in active_ids:
                inactive.append(vtrackno)

        for vtrackno in inactive:
            del self.hist[vtrackno]