import math
class CollisionDetector:
    
    def __init__(self):
        self.distance_threshold = 50
        self.speed_threshold = 2
        self.direction_threshold = 45
        self.closing_threshold = 1.5
       # self.acceleration_threshold = 3
        self.required_frames = 2

        self.previous_distances={}
        self.collision_frames={}

    def calculate_distance(self,p1,p2):
        return math.sqrt((p1[0]-p2[0])**2+(p1[1]-p2[1])**2)

    def direction_difference(self,d1,d2):
        if d1 is None or d2 is None:
            return None
        diff=abs(d1-d2)
        if diff>180:
            diff=360-diff
        return diff

    def detect(self,positions,speeds,directions,accelerations):
        collisions=[]

        ids=list(positions.keys())
        current_pairs=set()

        for i in range(len(ids)):
            for j in range(i+1,len(ids)):#comapring every pair every two vehicles like 1-2,1-3,2-3.. but not 2-1 bcz its same as 1-2
                id1=ids[i]
                id2=ids[j]

                pair=tuple(sorted((id1,id2)))
                current_pairs.add(pair)
#checking distance difference
                distance=self.calculate_distance(positions[id1],positions[id2])

                previous_distance=self.previous_distances.get(pair)
                self.previous_distances[pair]=distance

                if distance>self.distance_threshold:
                    self.collision_frames[pair]=0
                    continue

#checking spped difference
                speed1=speeds.get(id1,0)
                speed2=speeds.get(id2,0)

                if speed1<self.speed_threshold and speed2<self.speed_threshold:
                    self.collision_frames[pair]=0
                    continue

                # Check whether vehicles are getting closer
                if previous_distance is None:
                    continue

                distance_change=previous_distance-distance

                if distance_change<self.closing_threshold:
                    self.collision_frames[pair]=0
                    continue

                # direction checking
                direction1=directions.get(id1)
                direction2=directions.get(id2)

                direction_diff=self.direction_difference(direction1,direction2)

                if direction_diff is not None:
                    if direction_diff<self.direction_threshold:
                        self.collision_frames[pair]=0
                        continue

                
                acceleration1=accelerations.get(id1,0)
                acceleration2=accelerations.get(id2,0)
                # Count suspicious frames
                self.collision_frames[pair]=self.collision_frames.get(pair,0)+1

                # Confirm collision
                if self.collision_frames[pair]>=self.required_frames:
                    collisions.append((id1,id2,distance,speed1,speed2,direction_diff,acceleration1,acceleration2))

                    print(
                        f">>> COLLISION CONFIRMED: "
                        f"{id1}-{id2} | "
                        f"Distance: {distance:.2f} | "
                        f"Closing: {distance_change:.2f}"
                    )

                    self.collision_frames[pair]=0

        # Remove pairs that are no longer present
        old_pairs=set(self.previous_distances.keys())-current_pairs

        for pair in old_pairs:
            self.previous_distances.pop(pair,None)
            self.collision_frames.pop(pair,None)

        return collisions