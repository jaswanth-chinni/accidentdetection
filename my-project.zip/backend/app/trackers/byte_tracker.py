from ultralytics import YOLO


class ByteTrackerDetector:
    def __init__(self, model_path):
        self.model = YOLO(model_path)

    def track(self, frame):
        results = self.model.track(
            source=frame,
            persist=True,#vehicle ids same undalani true ..
            tracker="bytetrack.yaml",#ee algo vaadi tracking persistent ga undedhi
            #manaki ee vehicle classes consider cheyachu ani ikkada kuda ivachu classes=[1,2,3,4,5] ani
            verbose=False#unnessary console printings ni stop chestundhi
        )
        return results