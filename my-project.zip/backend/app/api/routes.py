import json
import os
import time
from pathlib import Path
from flask import Blueprint, jsonify, Response, request, send_from_directory, stream_with_context
from ..services.event_bus import event_bus

api = Blueprint("api", __name__)
accident_service = None


def set_accident_service(service):
    global accident_service
    accident_service = service


@api.get("/status")
def status():
    return jsonify(accident_service.get_status())


@api.get("/accident/latest")
def latest_accident():
    return jsonify(accident_service.get_status())


@api.get("/accidents")
def accidents():
    try:
        return jsonify({"items": accident_service.get_accidents(request.args.get("limit", 50))})
    except Exception as exc:
        return jsonify({"error": "Unable to retrieve accidents", "detail": str(exc)}), 503


@api.get("/events")
def events():
    """Server-Sent Events stream. Frontend connects once with EventSource."""
    subscriber = event_bus.subscribe()

    @stream_with_context
    def generate():
        try:
            yield "retry: 2000\n\n"
            yield f"event: connected\ndata: {json.dumps({'status': 'connected'})}\n\n"
            while True:
                try:
                    event = subscriber.get(timeout=15)
                    yield f"event: {event.get('type', 'message')}\ndata: {json.dumps(event.get('data', event), default=str)}\n\n"
                except Exception as exc:
                    if exc.__class__.__name__ != "Empty":
                        raise
                    yield f": heartbeat {int(time.time())}\n\n"
        finally:
            event_bus.unsubscribe(subscriber)

    response = Response(generate(), mimetype="text/event-stream")
    response.headers["Cache-Control"] = "no-cache"
    response.headers["X-Accel-Buffering"] = "no"
    response.headers["Connection"] = "keep-alive"
    return response


@api.get("/videos/<path:filename>")
def video(filename):
    """Serve clips from the same project-root folder used by VehicleDetector."""
    project_root = Path(__file__).resolve().parents[3]
    configured_dir = Path(os.getenv("ACCIDENT_VIDEO_DIR", "data/accident_clips"))
    video_dir = configured_dir if configured_dir.is_absolute() else project_root / configured_dir
    video_dir = video_dir.resolve()

    if not video_dir.is_dir():
        return jsonify({
            "error": "Accident video directory does not exist",
            "video_directory": str(video_dir),
        }), 404

    response = send_from_directory(video_dir, filename, conditional=True)
    response.headers["X-Content-Type-Options"] = "nosniff"
    return response


@api.post("/accident/reset")
def reset_accident():
    if os.getenv("ALLOW_ACCIDENT_RESET", "false").lower() != "true":
        return jsonify({"error": "Reset is disabled. Set ALLOW_ACCIDENT_RESET=true for development only."}), 403
    accident_service.reset()
    return jsonify({"success": True, "message": "Accident records cleared"})
