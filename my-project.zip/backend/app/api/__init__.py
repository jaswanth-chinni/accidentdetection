from .routes import api


def register_routes(app, accident_service):

    from . import routes

    routes.accident_service = accident_service

    app.register_blueprint(
        api,
        url_prefix="/api"
    )