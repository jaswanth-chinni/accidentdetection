import os
from datetime import datetime, timezone
from ..database.mongodb import MongoDB
from .event_bus import event_bus

class AccidentService:
    def __init__(self):
        self.db = MongoDB()
        self.recorded_pairs = set()
        # Track major events separately so a pair first seen as MINOR can later
        # produce a MAJOR event with its video clip if the severity thresholds are met.
        self.recorded_major_pairs = set()
        self.speed_severity_threshold = float(os.getenv("MAJOR_SPEED_THRESHOLD", "10"))
        self.acceleration_severity_threshold = float(os.getenv("MAJOR_ACCELERATION_THRESHOLD", "3"))
        self.accident_threshold = 2

    def calculate_severity(self, speed1, speed2, acceleration1, acceleration2):
        score = 0
        highest_speed = max(speed1, speed2)
        highest_acceleration = max(abs(acceleration1), abs(acceleration2))
        if highest_speed >= self.speed_severity_threshold:
            score += 1
        if highest_acceleration >= self.acceleration_severity_threshold:
            score += 1
        if highest_speed >= self.speed_severity_threshold and highest_acceleration >= self.acceleration_severity_threshold:
            score += 1
        major = score >= self.accident_threshold
        return ("MAJOR" if major else "MINOR"), score, major

    def record_collision(self, collision, clip_url=None):
        id1, id2, distance, speed1, speed2, direction_difference, acceleration1, acceleration2 = collision
        pair = tuple(sorted((id1, id2)))
        severity, score, major = self.calculate_severity(speed1, speed2, acceleration1, acceleration2)
        # One MINOR event per pair, but allow a later MAJOR upgrade exactly once.
        if pair in self.recorded_major_pairs:
            return None
        if pair in self.recorded_pairs and not major:
            return None
        # Do not publish/mark a MAJOR event until its browser-compatible clip
        # was saved. The detector can retry on a later frame if encoding fails.
        if major and not clip_url:
            print(f"MAJOR accident event deferred for pair {pair}: no valid video clip URL")
            return None
        self.recorded_pairs.add(pair)
        if major:
            self.recorded_major_pairs.add(pair)
        now = datetime.now(timezone.utc)
        lat = os.getenv("CAMERA_LATITUDE")
        lon = os.getenv("CAMERA_LONGITUDE")
        location = None
        if lat and lon:
            try:
                location = {"latitude": float(lat), "longitude": float(lon)}
            except ValueError:
                location = None
        event_id = f"acc-{now.strftime('%Y%m%dT%H%M%S%fZ')}"
        data = {
            "event_id": event_id,
            "camera_id": os.getenv("CAMERA_ID", "camera-01"),
            "vehicle_1": int(id1), "vehicle_2": int(id2),
            "distance": round(float(distance), 2),
            "speed_1": round(float(speed1), 2), "speed_2": round(float(speed2), 2),
            "direction_difference": None if direction_difference is None else round(float(direction_difference), 2),
            "acceleration_1": round(float(acceleration1), 2), "acceleration_2": round(float(acceleration2), 2),
            "severity": severity, "severity_score": score, "major_accident": major,
            "timestamp": now.isoformat(), "camera_location": location,
            "video_url": clip_url if major else None,
        }
        try:
            self.db.insert_accident(data)
        except Exception as exc:
            # Keep real-time alerting alive even if MongoDB is temporarily unavailable.
            data["storage_warning"] = "Database write failed; event may not persist."
            print(f"MongoDB insert failed: {exc}")
        event_bus.publish({"type": "accident.detected", "data": data})
        print(f"{severity} accident event published: {event_id}")
        return data

    def get_status(self):
        try:
            latest = self.db.get_latest_accident()
            total = self.db.get_total_accidents()
        except Exception as exc:
            return {"status": "degraded", "database_error": str(exc), "accident_detected": False, "latest_collision": None, "total_accidents": 0}
        return {"status": "running", "accident_detected": latest is not None, "latest_collision": latest, "total_accidents": total}

    def get_accidents(self, limit=50):
        return self.db.get_accidents(limit)

    def reset(self):
        self.db.clear_accidents()
        self.recorded_pairs.clear()
        self.recorded_major_pairs.clear()
